from __future__ import annotations

import json
from datetime import datetime, timezone

from ivsa.core.ecs_formatter import build_ecs_events, export_ndjson
from ivsa.core.models import (
    AnalysisMetadata,
    AnalysisResult,
    Anomaly,
    AnomalyCategory,
    CheckResult,
    ComplianceStatus,
    Severity,
)


def _sample_result() -> AnalysisResult:
    anomaly = Anomaly(
        rule_id="HDR-003",
        category=AnomalyCategory.STAS_VULNERABILITY,
        title="En-têtes SIP interdits",
        severity=Severity.CRITICAL,
        status=ComplianceStatus.FAIL,
        description="Referred-By interdit détecté.",
        technical_evidence="Referred-By: <sip:1001@10.10.0.5>",
        cyber_risk="Fuite d'adressage LAN.",
        remediation="Désactiver l'en-tête.",
        source_reference="Rapport Asterisk §5.2",
        frame_numbers=[1],
        call_id="call-1",
        sip_method="INVITE",
    )
    metadata = AnalysisMetadata(
        pcap_filename="test.pcapng",
        analysis_timestamp=datetime(2026, 7, 1, 12, 0, 0, tzinfo=timezone.utc),
        ruleset_name="Test Ruleset",
        ruleset_version="1.0.0",
    )
    checks = [CheckResult(rule_id="HDR-003", title="En-têtes SIP interdits", status=ComplianceStatus.FAIL, anomalies=[anomaly])]
    return AnalysisResult(metadata=metadata, checks=checks)


def test_build_ecs_events_contains_required_fields(rules_config):
    result = _sample_result()
    events = build_ecs_events(result, rules_config.siem_ecs)

    assert len(events) == 1
    event = events[0]
    assert event.event.category == ["network"]
    assert event.network.protocol == "sip"
    assert event.sip.method == "INVITE"
    assert event.sip.rule_id == "HDR-003"
    assert event.error.message == "Referred-By interdit détecté."
    assert event.event.severity == 90
    assert event.event.outcome == "failure"


def test_ecs_event_json_line_is_valid_json(rules_config):
    result = _sample_result()
    events = build_ecs_events(result, rules_config.siem_ecs)
    line = events[0].to_json_line()
    parsed = json.loads(line)

    assert parsed["event"]["category"] == ["network"]
    assert parsed["network"]["protocol"] == "sip"
    assert parsed["sip"]["method"] == "INVITE"
    assert parsed["error"]["message"]


def test_export_ndjson_writes_one_line_per_event(tmp_path, rules_config):
    result = _sample_result()
    output_path = tmp_path / "events.ndjson"

    count = export_ndjson(result, rules_config.siem_ecs, output_path)

    assert count == 1
    lines = output_path.read_text(encoding="utf-8").strip().splitlines()
    assert len(lines) == 1
    assert json.loads(lines[0])["sip"]["rule_id"] == "HDR-003"
