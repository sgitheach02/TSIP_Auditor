from __future__ import annotations

from datetime import datetime, timezone

import pytest
from pydantic import ValidationError

from ivsa.core.models import (
    AnalysisMetadata,
    AnalysisResult,
    Anomaly,
    AnomalyCategory,
    CheckResult,
    ComplianceStatus,
    NetworkEndpoint,
    Severity,
    SipDialog,
    SipMessage,
    Transport,
)


def _make_message(**overrides) -> SipMessage:
    defaults = dict(
        frame_number=1,
        timestamp=datetime.now(tz=timezone.utc),
        transport=Transport.UDP,
        source=NetworkEndpoint(ip="10.10.0.5", port=5060),
        destination=NetworkEndpoint(ip="203.0.113.10", port=5060),
        is_request=True,
        method="invite",
        call_id="abc-123",
    )
    defaults.update(overrides)
    return SipMessage(**defaults)


def test_network_endpoint_rejects_invalid_port():
    with pytest.raises(ValidationError):
        NetworkEndpoint(ip="10.0.0.1", port=70000)


def test_network_endpoint_detects_private_ip():
    assert NetworkEndpoint(ip="10.10.0.5", port=5060).is_private() is True
    assert NetworkEndpoint(ip="1.1.1.1", port=5060).is_private() is False


def test_sip_message_method_is_uppercased():
    message = _make_message(method="invite")
    assert message.method == "INVITE"
    assert message.label == "INVITE"


def test_sip_message_label_for_response():
    message = _make_message(is_request=False, method=None, status_code=486, reason_phrase="Busy Here")
    assert message.label == "486 Busy Here"


def test_sip_dialog_invite_and_bye_detection():
    invite = _make_message(method="INVITE", cseq_number=1)
    bye = _make_message(frame_number=2, method="BYE", cseq_number=2)
    dialog = SipDialog(call_id="abc-123", messages=[invite, bye])

    assert dialog.has_invite is True
    assert dialog.has_bye is True
    assert dialog.invite_cseq_numbers() == {1}
    assert dialog.bye_timestamp() == bye.timestamp


def test_anomaly_frame_numbers_are_sorted_and_deduplicated():
    anomaly = Anomaly(
        rule_id="TEST-001",
        category=AnomalyCategory.OTT_CONFORMITY,
        title="Test",
        severity=Severity.LOW,
        status=ComplianceStatus.FAIL,
        description="d",
        technical_evidence="e",
        cyber_risk="r",
        remediation="m",
        source_reference="ref",
        frame_numbers=[5, 1, 3, 1],
    )
    assert anomaly.frame_numbers == [1, 3, 5]


def test_analysis_result_counts_and_severity_breakdown():
    anomaly = Anomaly(
        rule_id="TEST-001",
        category=AnomalyCategory.STAS_VULNERABILITY,
        title="Test",
        severity=Severity.CRITICAL,
        status=ComplianceStatus.FAIL,
        description="d",
        technical_evidence="e",
        cyber_risk="r",
        remediation="m",
        source_reference="ref",
    )
    checks = [
        CheckResult(rule_id="A", title="A", status=ComplianceStatus.PASS),
        CheckResult(rule_id="B", title="B", status=ComplianceStatus.FAIL, anomalies=[anomaly]),
        CheckResult(rule_id="C", title="C", status=ComplianceStatus.WARNING),
    ]
    result = AnalysisResult(metadata=AnalysisMetadata(pcap_filename="x.pcapng"), checks=checks)

    assert result.pass_count == 1
    assert result.fail_count == 1
    assert result.warning_count == 1
    assert result.anomalies == [anomaly]
    assert result.severity_breakdown()[Severity.CRITICAL.value] == 1
    assert result.severity_breakdown()[Severity.LOW.value] == 0
