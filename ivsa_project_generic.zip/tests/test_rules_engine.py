from __future__ import annotations

from datetime import datetime, timedelta, timezone

from ivsa.core.models import (
    ComplianceStatus,
    FlowPurpose,
    NetworkEndpoint,
    NetworkFlow,
    OptionsKeepAlive,
    RtpTeardownSample,
    SdpCodec,
    SdpMediaDescription,
    Severity,
    SipDialog,
    SipMessage,
    Transport,
)
from ivsa.core.rules_engine import AncillaryFlowObservations, RuleEngine

_NOW = datetime(2026, 7, 1, 12, 0, 0, tzinfo=timezone.utc)


def _endpoint(ip: str, port: int = 5060) -> NetworkEndpoint:
    return NetworkEndpoint(ip=ip, port=port)


def _message(**overrides) -> SipMessage:
    defaults = dict(
        frame_number=1,
        timestamp=_NOW,
        transport=Transport.UDP,
        source=_endpoint("198.51.100.20"),
        destination=_endpoint("203.0.113.10"),
        is_request=True,
        method="INVITE",
        call_id="call-1",
    )
    defaults.update(overrides)
    return SipMessage(**defaults)


def test_nat_matrix_pass_when_all_flows_touch_declared_sbc(rules_config):
    engine = RuleEngine(rules_config)
    flows = [
        NetworkFlow(
            protocol=Transport.UDP,
            purpose=FlowPurpose.SIP_SIGNALING,
            local_endpoint=_endpoint("10.10.0.5"),
            remote_endpoint=_endpoint("203.0.113.10"),
            frame_numbers=[1],
        )
    ]
    result = engine.check_nat_matrix(flows, sbc_sip_endpoints=[_endpoint("203.0.113.10")])
    assert result.status == ComplianceStatus.PASS


def test_nat_matrix_fails_for_unknown_third_party_ip(rules_config):
    engine = RuleEngine(rules_config)
    flows = [
        NetworkFlow(
            protocol=Transport.UDP,
            purpose=FlowPurpose.SIP_SIGNALING,
            local_endpoint=_endpoint("10.10.0.5"),
            remote_endpoint=_endpoint("203.0.113.9"),
            frame_numbers=[1],
        )
    ]
    result = engine.check_nat_matrix(flows, sbc_sip_endpoints=[_endpoint("203.0.113.10")])
    assert result.status == ComplianceStatus.FAIL
    assert result.anomalies[0].severity == Severity.HIGH


def test_nat_matrix_does_not_double_count_bidirectional_flow(rules_config):
    engine = RuleEngine(rules_config)
    flows = [
        NetworkFlow(
            protocol=Transport.UDP,
            purpose=FlowPurpose.SIP_SIGNALING,
            local_endpoint=_endpoint("10.10.0.5"),
            remote_endpoint=_endpoint("203.0.113.10"),
            frame_numbers=[1],
        ),
        NetworkFlow(
            protocol=Transport.UDP,
            purpose=FlowPurpose.SIP_SIGNALING,
            local_endpoint=_endpoint("203.0.113.10"),
            remote_endpoint=_endpoint("10.10.0.5"),
            frame_numbers=[2],
        ),
    ]
    result = engine.check_nat_matrix(flows, sbc_sip_endpoints=[_endpoint("203.0.113.10")])
    assert result.status == ComplianceStatus.PASS


def test_identity_masking_flags_missing_pai(rules_config):
    engine = RuleEngine(rules_config)
    invite = _message(privacy="id", from_uri="sip:anonymous@anonymous.invalid")
    dialog = SipDialog(call_id="call-1", messages=[invite])

    result = engine.check_identity_masking([dialog])
    assert result.status == ComplianceStatus.FAIL
    assert result.anomalies[0].severity == Severity.HIGH


def test_identity_masking_passes_with_pai_and_privacy(rules_config):
    engine = RuleEngine(rules_config)
    invite = _message(
        privacy="id",
        from_uri="sip:anonymous@anonymous.invalid",
        p_asserted_identity="sip:0100000005@198.51.100.20",
    )
    dialog = SipDialog(call_id="call-1", messages=[invite])

    result = engine.check_identity_masking([dialog])
    assert result.status == ComplianceStatus.PASS


def test_identity_masking_not_applicable_for_regular_calls(rules_config):
    engine = RuleEngine(rules_config)
    invite = _message()
    dialog = SipDialog(call_id="call-1", messages=[invite])

    result = engine.check_identity_masking([dialog])
    assert result.status == ComplianceStatus.NOT_APPLICABLE


def test_forbidden_header_detects_referred_by_and_rfc1918_leak(rules_config):
    engine = RuleEngine(rules_config)
    message = _message(referred_by="<sip:1001@10.10.0.5>")

    result = engine.check_forbidden_headers([message])
    assert result.status == ComplianceStatus.FAIL
    assert "10.10.0.5" in result.anomalies[0].description
    assert result.anomalies[0].severity == Severity.CRITICAL


def test_forbidden_header_passes_when_absent(rules_config):
    engine = RuleEngine(rules_config)
    result = engine.check_forbidden_headers([_message()])
    assert result.status == ComplianceStatus.PASS


def test_authorized_methods_flags_non_stas_methods(rules_config):
    engine = RuleEngine(rules_config)
    message = _message(allow_methods=["INVITE", "ACK", "BYE", "REFER", "SUBSCRIBE"])

    result = engine.check_authorized_methods([message])
    flagged = {a.description for a in result.anomalies}
    assert result.status == ComplianceStatus.FAIL
    assert any("REFER" in d for d in flagged)
    assert any("SUBSCRIBE" in d for d in flagged)
    assert not any("INVITE" in d for d in flagged)


def test_codec_priority_fails_when_pcma_precedes_g729(rules_config):
    engine = RuleEngine(rules_config)
    media = SdpMediaDescription(
        media_type="audio",
        port=32010,
        protocol="RTP/AVP",
        codecs=[
            SdpCodec(payload_type=8, encoding_name="PCMA"),
            SdpCodec(payload_type=18, encoding_name="G729"),
        ],
    )
    message = _message(sdp_media=[media])

    result = engine.check_codec_priority([message])
    assert result.status == ComplianceStatus.FAIL


def test_codec_priority_passes_when_g729_precedes_pcma(rules_config):
    engine = RuleEngine(rules_config)
    media = SdpMediaDescription(
        media_type="audio",
        port=32010,
        protocol="RTP/AVP",
        codecs=[
            SdpCodec(payload_type=18, encoding_name="G729"),
            SdpCodec(payload_type=8, encoding_name="PCMA"),
        ],
    )
    message = _message(sdp_media=[media])

    result = engine.check_codec_priority([message])
    assert result.status == ComplianceStatus.PASS


def test_fax_conformity_flags_t38(rules_config):
    engine = RuleEngine(rules_config)
    media = SdpMediaDescription(
        media_type="image", port=32012, protocol="udptl", codecs=[SdpCodec(payload_type=None, encoding_name="T38")]
    )
    message = _message(sdp_media=[media])

    result = engine.check_fax_conformity([message])
    assert result.status == ComplianceStatus.FAIL
    assert result.anomalies[0].severity == Severity.HIGH


def test_ancillary_encryption_flags_cleartext_smtp_and_imap(rules_config):
    engine = RuleEngine(rules_config)
    observations = AncillaryFlowObservations(
        sip_trunk_observed=True,
        sip_trunk_uses_tls=False,
        smtp_observed=True,
        smtp_uses_tls=False,
        imap_observed=True,
        imap_uses_oauth2=False,
    )
    result = engine.check_ancillary_encryption(observations)
    assert result.status == ComplianceStatus.FAIL
    severities = {a.severity for a in result.anomalies}
    assert Severity.HIGH in severities
    assert Severity.INFO in severities


def test_ancillary_encryption_passes_when_nothing_observed(rules_config):
    engine = RuleEngine(rules_config)
    result = engine.check_ancillary_encryption(AncillaryFlowObservations())
    assert result.status == ComplianceStatus.PASS


def test_rfc3261_state_machine_flags_orphan_response(rules_config):
    engine = RuleEngine(rules_config)
    invite = _message(cseq_number=1)
    orphan_486 = _message(
        frame_number=2,
        is_request=False,
        method=None,
        status_code=486,
        reason_phrase="Busy Here",
        cseq_number=99,
    )
    dialog = SipDialog(call_id="call-1", messages=[invite, orphan_486])

    result = engine.check_rfc3261_state_machine([dialog])
    assert result.status == ComplianceStatus.FAIL
    assert result.anomalies[0].severity == Severity.HIGH


def test_rfc3261_state_machine_passes_for_matching_cseq(rules_config):
    engine = RuleEngine(rules_config)
    invite = _message(cseq_number=1)
    valid_486 = _message(
        frame_number=2, is_request=False, method=None, status_code=486, reason_phrase="Busy Here", cseq_number=1
    )
    dialog = SipDialog(call_id="call-1", messages=[invite, valid_486])

    result = engine.check_rfc3261_state_machine([dialog])
    assert result.status == ComplianceStatus.PASS


def test_rtp_teardown_flags_persistent_traffic_beyond_tolerance(rules_config):
    engine = RuleEngine(rules_config)
    sample = RtpTeardownSample(
        call_id="call-1",
        bye_timestamp=_NOW,
        last_rtp_timestamp=_NOW + timedelta(milliseconds=200),
        frames_after_bye=[10, 11],
        delay_after_bye_ms=200.0,
    )
    result = engine.check_rtp_teardown([sample])
    assert result.status == ComplianceStatus.FAIL


def test_rtp_teardown_passes_within_tolerance(rules_config):
    engine = RuleEngine(rules_config)
    sample = RtpTeardownSample(
        call_id="call-1",
        bye_timestamp=_NOW,
        last_rtp_timestamp=_NOW + timedelta(milliseconds=10),
        frames_after_bye=[10],
        delay_after_bye_ms=10.0,
    )
    result = engine.check_rtp_teardown([sample])
    assert result.status == ComplianceStatus.PASS


def test_trunk_supervision_flags_irregular_options_period(rules_config):
    engine = RuleEngine(rules_config)
    keepalive = OptionsKeepAlive(
        source=_endpoint("198.51.100.20"),
        destination=_endpoint("203.0.113.10"),
        timestamps=[_NOW, _NOW + timedelta(seconds=60), _NOW + timedelta(seconds=200)],
        frame_numbers=[1, 2, 3],
    )
    result = engine.check_trunk_supervision([keepalive])
    assert result.status == ComplianceStatus.FAIL


def test_trunk_supervision_passes_for_regular_60s_period(rules_config):
    engine = RuleEngine(rules_config)
    keepalive = OptionsKeepAlive(
        source=_endpoint("198.51.100.20"),
        destination=_endpoint("203.0.113.10"),
        timestamps=[_NOW, _NOW + timedelta(seconds=60), _NOW + timedelta(seconds=120)],
        frame_numbers=[1, 2, 3],
    )
    result = engine.check_trunk_supervision([keepalive])
    assert result.status == ComplianceStatus.PASS


def test_run_all_returns_ten_checks(rules_config):
    engine = RuleEngine(rules_config)
    checks = engine.run_all(dialogs=[], messages=[], flows=[])
    assert len(checks) == 10
    assert {c.rule_id for c in checks} == {
        "NAT-001",
        "ID-002",
        "HDR-003",
        "MET-004",
        "COD-005",
        "FAX-006",
        "ENC-007",
        "RFC-008",
        "RTP-009",
        "SUP-010",
    }
