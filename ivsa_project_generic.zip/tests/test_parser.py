from __future__ import annotations

import pytest

from ivsa.core.exceptions import PcapParsingError
from ivsa.core.models import ComplianceStatus
from ivsa.core.parser import PcapAnalyzer
from ivsa.core.rules_engine import RuleEngine
from tests.conftest import requires_tshark


def test_pcap_analyzer_rejects_missing_file(tmp_path):
    with pytest.raises(PcapParsingError):
        PcapAnalyzer(tmp_path / "does-not-exist.pcapng")


@requires_tshark
def test_extract_sip_messages_from_full_scenario(full_scenario_pcap):
    analyzer = PcapAnalyzer(full_scenario_pcap)
    messages = analyzer.extract_sip_messages()

    assert len(messages) > 0
    call_ids = {m.call_id for m in messages}
    assert "call-1" in call_ids  # Referred-By leak / codec order
    assert "call-2" in call_ids  # masked call missing PAI
    assert "call-3" in call_ids  # compliant masked call
    assert "call-4" in call_ids  # T.38 fax negotiation

    invite_call_1 = next(m for m in messages if m.call_id == "call-1" and m.method == "INVITE")
    assert invite_call_1.referred_by == "<sip:1001@10.10.0.5>"
    assert invite_call_1.sdp_media[0].codec_order() == ["PCMA", "G729", "telephone-event"]


@requires_tshark
def test_build_dialogs_groups_by_call_id(full_scenario_pcap):
    analyzer = PcapAnalyzer(full_scenario_pcap)
    messages = analyzer.extract_sip_messages()
    dialogs = analyzer.build_dialogs(messages)

    dialog_call_1 = next(d for d in dialogs if d.call_id == "call-1")
    assert dialog_call_1.has_invite is True
    assert dialog_call_1.has_bye is True


@requires_tshark
def test_extract_network_flows_classifies_sip_and_rtp(full_scenario_pcap):
    analyzer = PcapAnalyzer(full_scenario_pcap)
    messages = analyzer.extract_sip_messages()
    flows = analyzer.extract_network_flows(messages)

    purposes = {flow.purpose.value for flow in flows}
    assert "sip" in purposes


@requires_tshark
def test_extract_rtp_teardown_samples_detects_lingering_rtp(full_scenario_pcap):
    analyzer = PcapAnalyzer(full_scenario_pcap)
    messages = analyzer.extract_sip_messages()
    dialogs = analyzer.build_dialogs(messages)
    samples = analyzer.extract_rtp_teardown_samples(dialogs)

    assert any(s.call_id == "call-1" and s.delay_after_bye_ms > 0 for s in samples)


@requires_tshark
def test_extract_keepalives_computes_period(full_scenario_pcap):
    analyzer = PcapAnalyzer(full_scenario_pcap)
    messages = analyzer.extract_sip_messages()
    keepalives = analyzer.extract_keepalives(messages)

    assert len(keepalives) == 1
    intervals = keepalives[0].intervals_seconds()
    assert all(abs(i - 60.0) < 0.5 for i in intervals)


@requires_tshark
def test_full_scenario_triggers_expected_rule_violations(full_scenario_pcap, rules_config):
    analyzer = PcapAnalyzer(full_scenario_pcap)
    messages = analyzer.extract_sip_messages()
    dialogs = analyzer.build_dialogs(messages)
    flows = analyzer.extract_network_flows(messages)
    rtp_samples = analyzer.extract_rtp_teardown_samples(dialogs)
    keepalives = analyzer.extract_keepalives(messages)
    ancillary = analyzer.detect_ancillary_observations(messages)

    engine = RuleEngine(rules_config)
    checks = engine.run_all(
        dialogs=dialogs,
        messages=messages,
        flows=flows,
        rtp_teardown_samples=rtp_samples,
        keepalives=keepalives,
        ancillary_observations=ancillary,
    )
    status_by_rule = {c.rule_id: c.status for c in checks}

    assert status_by_rule["ID-002"] == ComplianceStatus.FAIL  # masked call missing PAI
    assert status_by_rule["HDR-003"] == ComplianceStatus.FAIL  # Referred-By leak
    assert status_by_rule["MET-004"] == ComplianceStatus.FAIL  # unauthorized methods
    assert status_by_rule["COD-005"] == ComplianceStatus.FAIL  # codec order
    assert status_by_rule["FAX-006"] == ComplianceStatus.FAIL  # T.38
    assert status_by_rule["RFC-008"] == ComplianceStatus.FAIL  # orphan 486
    assert status_by_rule["RTP-009"] == ComplianceStatus.FAIL  # RTP after BYE
    assert status_by_rule["SUP-010"] == ComplianceStatus.PASS  # regular OPTIONS
