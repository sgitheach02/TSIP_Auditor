from __future__ import annotations

from datetime import datetime, timezone

import pytest
from docx import Document

from ivsa.core.exceptions import ReportGenerationError
from ivsa.core.models import (
    AnalysisMetadata,
    AnalysisResult,
    Anomaly,
    AnomalyCategory,
    CheckResult,
    ComplianceStatus,
    Severity,
)
from ivsa.core.reporter import DEFAULT_TEMPLATE_PATH, ReportBuilder


def _sample_result() -> AnalysisResult:
    anomaly = Anomaly(
        rule_id="HDR-003",
        category=AnomalyCategory.STAS_VULNERABILITY,
        title="En-têtes SIP interdits",
        severity=Severity.CRITICAL,
        status=ComplianceStatus.FAIL,
        description="Referred-By interdit détecté, expose <sip:1001@10.10.0.5>.",
        technical_evidence="Referred-By: <sip:1001@10.10.0.5> (trame 1).",
        cyber_risk="Fuite d'adressage LAN interne.",
        remediation="Désactiver l'émission de l'en-tête Referred-By.",
        source_reference="Rapport Asterisk §5.2",
        frame_numbers=[1],
        call_id="call-1",
    )
    metadata = AnalysisMetadata(
        pcap_filename="test.pcapng",
        client_name="Client Test",
        analysis_timestamp=datetime(2026, 7, 1, 12, 0, 0, tzinfo=timezone.utc),
        ruleset_name="Test Ruleset",
        ruleset_version="1.0.0",
    )
    checks = [
        CheckResult(rule_id="NAT-001", title="Matrice NAT", status=ComplianceStatus.PASS),
        CheckResult(
            rule_id="HDR-003", title="En-têtes SIP interdits", status=ComplianceStatus.FAIL, anomalies=[anomaly]
        ),
    ]
    return AnalysisResult(metadata=metadata, checks=checks)


def test_report_builder_rejects_missing_template(tmp_path):
    with pytest.raises(ReportGenerationError):
        ReportBuilder(tmp_path / "missing.docx")


def test_default_template_exists():
    assert DEFAULT_TEMPLATE_PATH.is_file()


def test_render_produces_valid_docx_with_no_leftover_jinja_tags(tmp_path):
    builder = ReportBuilder()
    result = _sample_result()
    output_path = tmp_path / "rapport.docx"

    rendered_path = builder.render(result, output_path, ruleset_sources=["Source A", "Source B"])

    assert rendered_path == output_path
    assert output_path.is_file()

    document = Document(str(output_path))
    full_text = "\n".join(p.text for p in document.paragraphs)
    for table in document.tables:
        for row in table.rows:
            full_text += "\n" + "\n".join(cell.text for cell in row.cells)

    assert "{%" not in full_text
    assert "{{" not in full_text
    assert "Client Test" in full_text
    assert "Referred-By interdit détecté" in full_text
    assert "<sip:1001@10.10.0.5>" in full_text
    assert "Source A" in full_text
    assert "Source B" in full_text


def test_render_reflects_pass_fail_counts(tmp_path):
    builder = ReportBuilder()
    result = _sample_result()
    output_path = tmp_path / "rapport.docx"
    builder.render(result, output_path, ruleset_sources=[])

    document = Document(str(output_path))
    summary_table = document.tables[1]
    values = {row.cells[0].text: row.cells[1].text for row in summary_table.rows[1:]}
    assert values["Conforme (PASS)"] == "1"
    assert values["Non conforme (FAIL)"] == "1"
