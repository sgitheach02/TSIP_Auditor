from __future__ import annotations

from ivsa.core.sdp import decode_message_body, parse_sdp_body


def test_parse_sdp_body_single_media_preserves_codec_order():
    body = (
        "v=0\r\no=- 1 1 IN IP4 10.10.0.5\r\ns=-\r\nc=IN IP4 10.10.0.5\r\nt=0 0\r\n"
        "m=audio 32010 RTP/AVP 8 18 101\r\n"
        "a=rtpmap:8 PCMA/8000\r\na=rtpmap:18 G729/8000\r\n"
        "a=rtpmap:101 telephone-event/8000\r\na=ptime:20\r\n"
    )
    media = parse_sdp_body(body)

    assert len(media) == 1
    assert media[0].media_type == "audio"
    assert media[0].port == 32010
    assert media[0].codec_order() == ["PCMA", "G729", "telephone-event"]
    assert media[0].ptime_ms == 20
    assert media[0].connection_address == "10.10.0.5"


def test_parse_sdp_body_multiple_media_blocks():
    body = (
        "v=0\r\no=- 1 1 IN IP4 10.10.0.5\r\ns=-\r\nc=IN IP4 10.10.0.5\r\nt=0 0\r\n"
        "m=audio 32010 RTP/AVP 8 18\r\na=rtpmap:8 PCMA/8000\r\na=rtpmap:18 G729/8000\r\n"
        "m=image 32012 udptl t38\r\n"
    )
    media = parse_sdp_body(body)

    assert len(media) == 2
    assert media[0].media_type == "audio"
    assert media[0].codec_order() == ["PCMA", "G729"]
    assert media[1].media_type == "image"
    assert media[1].codec_order() == ["T38"]
    assert media[1].protocol == "udptl"


def test_parse_sdp_body_uses_static_payload_type_table_when_no_rtpmap():
    body = "v=0\r\no=- 1 1 IN IP4 10.0.0.1\r\ns=-\r\nc=IN IP4 10.0.0.1\r\nt=0 0\r\nm=audio 4000 RTP/AVP 0 8\r\n"
    media = parse_sdp_body(body)

    assert media[0].codec_order() == ["PCMU", "PCMA"]


def test_parse_sdp_body_empty_returns_no_media():
    assert parse_sdp_body("") == []
    assert parse_sdp_body("   \r\n  ") == []


def test_decode_message_body_hex_colon_roundtrip():
    text = "v=0\r\no=- 1 1 IN IP4 10.0.0.1\r\n"
    hex_colon = ":".join(f"{b:02x}" for b in text.encode())
    assert decode_message_body(hex_colon) == text


def test_decode_message_body_passthrough_for_plain_text():
    assert decode_message_body("already plain text") == "already plain text"


def test_decode_message_body_empty_string():
    assert decode_message_body("") == ""
